package com.pedestriamc.namecolor;

import com.earth2me.essentials.Essentials;
import com.earth2me.essentials.User;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class SetNameColor {
    private static boolean useEssentials = false;
    private static Essentials essentials;
    public static void initialize(){
        if(NameColor.getInstance().getMode().equals("essentials")){
            useEssentials = true;
            essentials = (Essentials) Bukkit.getPluginManager().getPlugin("Essentials");
        }
    }
    public static void setColor(Player player, ChatColor color, boolean save){ //ChatColor mode
        if(useEssentials){
            User user = essentials.getUser(player.getUniqueId());
            StoredPlayers.saveStoredPlayer(new StoredPlayer(player, color));
            player.setDisplayName(color + player.getName());
            user.setNickname(color + player.getName());
        }else{
            player.setDisplayName(color + player.getName());
        }
        if(save){
            StoredPlayers.saveStoredPlayer(new StoredPlayer(player, color));
        }
    }
    public static void setColor(Player player, String color, boolean save){ //RGB mode
        if(useEssentials){
            Essentials essentials = (Essentials) Bukkit.getPluginManager().getPlugin("Essentials");
            User user = essentials.getUser(player.getUniqueId());
            player.setDisplayName(ChatColor.of(color) + player.getName());
            user.setNickname(ChatColor.of(color) + player.getName());
        }else{
            player.setDisplayName(ChatColor.of(color) + player.getName());
            player.setPlayerListName(ChatColor.of(color) + player.getName());
        }
        if(save){
            StoredPlayers.saveStoredPlayer(new StoredPlayer(player, color, false));
        }

    }
}
